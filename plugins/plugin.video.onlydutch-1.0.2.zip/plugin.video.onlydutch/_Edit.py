import xbmcaddon

MainBase = 'http://goo.gl/SdOoIc'
addon = xbmcaddon.Addon('plugin.video.onlydutch')